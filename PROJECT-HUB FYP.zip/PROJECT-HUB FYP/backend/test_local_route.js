const axios = require('axios');

async function testLocalRoute() {
    console.log('Testing http://localhost:3000/api/github/repos/ali-marwat ...');
    try {
        const response = await axios.get('http://localhost:3000/api/github/repos/ali-marwat');
        console.log('✅ Success!');
        console.log('Status:', response.status);
        console.log('Data count:', response.data.length);
    } catch (error) {
        console.log('❌ Error!');
        if (error.response) {
            console.log('Status:', error.response.status);
            console.log('Status Text:', error.response.statusText);
            console.log('Data:', error.response.data);
            if (error.response.status === 404) {
                console.log('>>> CONCLUSION: The server is running but does NOT recognize the /api/github route.');
                console.log('>>> SOLUTION: The server code needs to be restarted or saved.');
            }
        } else {
            console.log('Error:', error.message);
            console.log('Is the server running?');
        }
    }
}

testLocalRoute();
