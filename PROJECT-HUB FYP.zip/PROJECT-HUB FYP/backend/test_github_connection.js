require('dotenv').config();
const axios = require('axios');

const token = process.env.GITHUB_TOKEN;
const username = 'ali-marwat';

console.log('--- GitHub Connection Test ---');
console.log(`Token loaded: ${token ? 'Yes (' + token.substring(0, 4) + '...)' : 'No'}`);

async function testConnection() {
    const headers = {
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'ProjectHub-Debug'
    };

    if (token) {
        headers['Authorization'] = `token ${token}`;
    }

    console.log(`\nAttempting to fetch repos for user: ${username}...`);

    try {
        const response = await axios.get(`https://api.github.com/users/${username}/repos?sort=updated&per_page=5`, { headers });
        console.log('✅ Success!');
        console.log(`Status: ${response.status}`);
        console.log(`Found ${response.data.length} repos.`);
        if (response.data.length > 0) {
            console.log(`First repo: ${response.data[0].name}`);
        }
    } catch (error) {
        console.log('❌ Error!');
        if (error.response) {
            console.log(`Status: ${error.response.status}`);
            console.log(`Data:`, error.response.data);
            console.log(`Headers:`, error.response.headers);
        } else {
            console.log(error.message);
        }
    }
}

testConnection();
